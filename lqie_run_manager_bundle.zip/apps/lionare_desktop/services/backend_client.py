from __future__ import annotations

import json
from typing import Any

from PySide6.QtCore import QObject, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest


class BackendClient(QObject):
    """Small asynchronous JSON client for the existing Lionare local API."""

    received = Signal(str, object)
    failed = Signal(str, str)

    def __init__(self, base_url: str, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.base_url = base_url.rstrip("/")
        self.manager = QNetworkAccessManager(self)

    def get(self, path: str) -> None:
        clean_path = "/" + path.lstrip("/")
        request = QNetworkRequest(QUrl(self.base_url + clean_path))
        request.setRawHeader(b"Accept", b"application/json")
        request.setTransferTimeout(5_000)
        reply = self.manager.get(request)
        reply.setProperty("lionare_path", clean_path)
        reply.finished.connect(lambda current=reply: self._finish(current))

    def _finish(self, reply: Any) -> None:
        path = str(reply.property("lionare_path") or "unknown")
        try:
            if reply.error():
                self.failed.emit(path, reply.errorString())
                return
            raw = bytes(reply.readAll())
            try:
                payload = json.loads(raw.decode("utf-8")) if raw else {}
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                self.failed.emit(path, f"Invalid JSON response: {exc}")
                return
            self.received.emit(path, payload)
        finally:
            reply.deleteLater()
