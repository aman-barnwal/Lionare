"""Backend communication services."""
