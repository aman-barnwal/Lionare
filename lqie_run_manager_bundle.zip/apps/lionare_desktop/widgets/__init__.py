"""Dockable terminal widgets."""
