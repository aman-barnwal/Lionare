from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPainter, QPen, QColor, QFont
from PySide6.QtWidgets import (
    QFrame,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..config import DATA_LAKE_ROOT, GLOBAL_MARKETS, WATCHLIST


def _text(value: Any, fallback: str = "—") -> str:
    if value is None or value == "":
        return fallback
    if isinstance(value, (dict, list)):
        return str(value)
    return str(value)


def _extract_list(payload: Any, keys: tuple[str, ...]) -> list[Any]:
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in keys:
            value = payload.get(key)
            if isinstance(value, list):
                return value
    return []


class Panel(QWidget):
    def __init__(self, title: str, subtitle: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("panelBody")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(10, 8, 10, 10)
        self.layout.setSpacing(7)
        heading = QHBoxLayout()
        self.title_label = QLabel(title.upper())
        self.title_label.setObjectName("panelHeading")
        heading.addWidget(self.title_label)
        heading.addStretch(1)
        self.status_label = QLabel(subtitle.upper())
        self.status_label.setObjectName("panelMeta")
        heading.addWidget(self.status_label)
        self.layout.addLayout(heading)
        self.content_layout = QVBoxLayout()
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(6)
        self.layout.addLayout(self.content_layout, 1)

    def set_meta(self, text: str) -> None:
        self.status_label.setText(text.upper())

    def add_note(self, text: str, object_name: str = "mutedText") -> QLabel:
        label = QLabel(text)
        label.setObjectName(object_name)
        label.setWordWrap(True)
        self.content_layout.addWidget(label)
        return label


class SimpleTablePanel(Panel):
    def __init__(self, title: str, headers: list[str], rows: list[list[str]], subtitle: str = "") -> None:
        super().__init__(title, subtitle)
        self.table = QTableWidget(len(rows), len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.content_layout.addWidget(self.table)
        self.set_rows(rows)

    def set_rows(self, rows: list[list[str]]) -> None:
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                item = QTableWidgetItem(_text(value))
                if c > 0:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
                self.table.setItem(r, c, item)
        self.table.resizeColumnsToContents()


class GlobalMarketsPanel(SimpleTablePanel):
    def __init__(self) -> None:
        rows = [[name, region, "—", "FEED PENDING"] for name, region in GLOBAL_MARKETS]
        super().__init__("Global Markets", ["INDEX", "REGION", "LAST", "STATUS"], rows, "REFERENCE LIST")
        self.table.setColumnWidth(0, 135)
        self.table.setColumnWidth(1, 110)


class WatchlistPanel(SimpleTablePanel):
    def __init__(self) -> None:
        rows = [[symbol, name, "—", "NOT CONNECTED"] for symbol, name in WATCHLIST]
        super().__init__("Watchlist", ["SYMBOL", "COMPANY", "LAST", "PRICE FEED"], rows, "10 COMPANIES")
        self.table.setColumnWidth(0, 70)
        self.table.setColumnWidth(1, 190)

    def update_companies(self, payload: Any) -> None:
        records = _extract_list(payload, ("companies", "items", "results", "data"))
        if not records:
            return
        rows: list[list[str]] = []
        for record in records:
            if isinstance(record, dict):
                symbol = _text(record.get("symbol") or record.get("ticker"))
                company = _text(record.get("name") or record.get("company"))
            else:
                symbol, company = _text(record), ""
            if symbol != "—":
                rows.append([symbol, company, "—", "PRICE FEED PENDING"])
        if rows:
            self.set_rows(rows)
            self.set_meta(f"{len(rows)} COMPANIES · PRICE FEED NOT CONNECTED")


class CompanyResearchPanel(Panel):
    symbol_changed = Signal(str)

    def __init__(self) -> None:
        super().__init__("Company Research", "SEC FUNDAMENTALS")
        self.selector = QComboBox()
        for symbol, name in WATCHLIST:
            self.selector.addItem(f"{symbol}  ·  {name}", symbol)
        self.selector.currentIndexChanged.connect(self._selection_changed)
        self.content_layout.addWidget(self.selector)
        self.company_name = self.add_note("Apple Inc.", "goodText")
        self.company_meta = self.add_note("AAPL · awaiting backend response")
        self.metric_labels: dict[str, QLabel] = {}
        for key, caption in (("revenue", "LATEST ANNUAL REVENUE"), ("net_income", "LATEST NET INCOME"), ("assets", "TOTAL ASSETS"), ("coverage", "HISTORICAL COVERAGE")):
            block = QLabel(f"{caption}\n—")
            block.setObjectName("metricBlock")
            block.setWordWrap(True)
            self.content_layout.addWidget(block)
            self.metric_labels[key] = block
        self._selection_changed()

    def _selection_changed(self, *_: Any) -> None:
        symbol = str(self.selector.currentData() or "AAPL")
        self.company_meta.setText(f"{symbol} · REQUESTING COMPANY DATA")
        self.symbol_changed.emit(symbol)

    def update_company(self, payload: Any) -> None:
        record = payload
        if isinstance(payload, dict):
            for key in ("company", "data", "result"):
                if isinstance(payload.get(key), dict):
                    record = payload[key]
                    break
        if not isinstance(record, dict):
            self.company_meta.setText("Unexpected company response shape")
            return
        symbol = _text(record.get("symbol") or record.get("ticker"), str(self.selector.currentData() or "AAPL"))
        name = _text(record.get("name") or record.get("company_name"), symbol)
        industry = _text(record.get("industry") or record.get("sector"), "SEC XBRL")
        self.company_name.setText(name)
        self.company_meta.setText(f"{symbol} · {industry} · SEC XBRL")
        metrics = record.get("metrics") if isinstance(record.get("metrics"), dict) else record
        mapping = {
            "revenue": ("revenue", "latest_revenue", "annual_revenue"),
            "net_income": ("net_income", "netincome", "latest_net_income"),
            "assets": ("assets", "total_assets"),
            "coverage": ("coverage", "observations", "historical_coverage"),
        }
        captions = {"revenue": "LATEST ANNUAL REVENUE", "net_income": "LATEST NET INCOME", "assets": "TOTAL ASSETS", "coverage": "HISTORICAL COVERAGE"}
        for key, candidates in mapping.items():
            value = next((metrics.get(candidate) for candidate in candidates if metrics.get(candidate) is not None), None)
            self.metric_labels[key].setText(f"{captions[key]}\n{_text(value)}")


class MarketPulsePanel(Panel):
    def __init__(self) -> None:
        super().__init__("Market Pulse", "WAITING FOR PRICE FEED")
        self.value = self.add_note("Market breadth and sentiment will appear when a validated market-price source is connected.")
        self.add_note("No synthetic or placeholder market statistics are displayed.")


class PortfolioPanel(Panel):
    def __init__(self) -> None:
        super().__init__("Portfolio Summary", "NO PORTFOLIO")
        self.value = self.add_note("No portfolio has been configured.")
        self.add_note("Holdings, exposure, daily P&L and total return will be calculated from saved positions and permitted market prices.")


class PerformancePanel(Panel):
    def __init__(self) -> None:
        super().__init__("Performance Tracker", "DATA SOURCE PENDING")
        self.value = self.add_note("No verified live or historical market-price feed is connected.")
        self.add_note("Performance metrics will remain unavailable until price data is integrated.")


class NewsPanel(Panel):
    def __init__(self) -> None:
        super().__init__("News & Events", "OFFICIAL / INGESTED FEEDS")
        self.list_widget = QListWidget()
        self.content_layout.addWidget(self.list_widget)
        self.list_widget.addItem("Waiting for the existing Lionare news service…")

    def update_news(self, payload: Any) -> None:
        records = _extract_list(payload, ("news", "items", "articles", "results", "data"))
        self.list_widget.clear()
        if not records:
            self.list_widget.addItem("No news records returned by the backend.")
            return
        for record in records[:100]:
            if isinstance(record, dict):
                title = _text(record.get("title") or record.get("headline"), "Untitled item")
                source = _text(record.get("source") or record.get("publisher"), "Source unavailable")
                published = _text(record.get("published") or record.get("published_at") or record.get("date"), "")
                item = QListWidgetItem(f"{title}\n{source}  ·  {published}")
                url = record.get("url") or record.get("link")
                if url:
                    item.setData(Qt.ItemDataRole.UserRole, str(url))
            else:
                item = QListWidgetItem(_text(record))
            self.list_widget.addItem(item)
        self.set_meta(f"{min(len(records), 100)} ITEMS")


class QuantPanel(Panel):
    def __init__(self, lqie_available: bool, trendline_status: str) -> None:
        super().__init__("LQIE Quant Lab", "ENGINE STATUS")
        self.add_note(f"LQIE package: {'AVAILABLE' if lqie_available else 'NOT FOUND'}", "goodText" if lqie_available else "warnText")
        self.add_note("Pattern engine: 0.5 experimental branch", "mutedText")
        self.add_note("Candlesticks: TA-Lib integration installed", "mutedText")
        self.add_note(f"Trendlines: {trendline_status}", "warnText" if "pending" in trendline_status.lower() else "mutedText")
        self.add_note("No pattern analysis is being run in this desktop process yet. The engine remains a separate service/task.")


class DataLakePanel(Panel):
    def __init__(self) -> None:
        super().__init__("Data Lake", "LOCAL STORAGE")
        self.summary = self.add_note("Scanning local data lake…")
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["LAYER", "PARQUET FILES", "SIZE"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.content_layout.addWidget(self.table)
        self.refresh_local()

    def refresh_local(self) -> None:
        if not DATA_LAKE_ROOT.exists():
            self.summary.setText(f"Data lake not found: {DATA_LAKE_ROOT}")
            self.table.setRowCount(0)
            return
        rows: list[tuple[str, int, int]] = []
        total_bytes = 0
        for layer in ("bronze", "silver", "gold", "catalog", "metadata"):
            path = DATA_LAKE_ROOT / layer
            files = list(path.rglob("*.parquet")) if path.exists() else []
            size = sum(f.stat().st_size for f in files if f.is_file())
            rows.append((layer.upper(), len(files), size))
            total_bytes += size
        self.summary.setText(f"{DATA_LAKE_ROOT}  ·  {total_bytes / (1024 * 1024):.2f} MB PARQUET")
        self.table.setRowCount(len(rows))
        for r, (layer, count, size) in enumerate(rows):
            for c, value in enumerate((layer, str(count), f"{size / 1024:.1f} KB")):
                self.table.setItem(r, c, QTableWidgetItem(value))
        self.table.resizeColumnsToContents()


class SystemPanel(Panel):
    def __init__(self, api_url: str) -> None:
        super().__init__("System Status", "LOCAL NODE")
        self.backend = self.add_note("Backend: CHECKING…")
        self.backend_url = self.add_note(f"API endpoint: {api_url}")
        self.storage = self.add_note(f"Data lake: {DATA_LAKE_ROOT}")
        self.runtime = self.add_note(f"Desktop: Lionare Terminal 0.1.0")
        self.last_update = self.add_note("Last refresh: —")

    def set_backend(self, online: bool, detail: str = "") -> None:
        self.backend.setText(f"Backend: {'ONLINE' if online else 'OFFLINE'}" + (f" · {detail}" if detail else ""))
        self.backend.setObjectName("goodText" if online else "warnText")
        self.backend.style().unpolish(self.backend)
        self.backend.style().polish(self.backend)
        self.last_update.setText("Last refresh: " + datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"))


class ChartWorkspace(QFrame):
    """Honest chart surface until real OHLCV data is wired in."""

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("chartWorkspace")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)
        top = QHBoxLayout()
        title = QLabel("MARKET CHART")
        title.setObjectName("chartTitle")
        top.addWidget(title)
        top.addStretch(1)
        self.symbol = QLabel("AAPL · DAILY")
        self.symbol.setObjectName("panelMeta")
        top.addWidget(self.symbol)
        layout.addLayout(top)
        self.canvas = ChartCanvas()
        layout.addWidget(self.canvas, 1)
        footer = QLabel("OHLCV PRICE FEED NOT CONNECTED · SEC FUNDAMENTALS ARE NOT STOCK PRICES")
        footer.setObjectName("warnText")
        layout.addWidget(footer)


class ChartCanvas(QWidget):
    def paintEvent(self, event: Any) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect()
        painter.fillRect(rect, QColor("#090e15"))
        grid_pen = QPen(QColor("#1c2a37"), 1, Qt.PenStyle.SolidLine)
        painter.setPen(grid_pen)
        for i in range(1, 9):
            y = int(rect.height() * i / 9)
            painter.drawLine(0, y, rect.width(), y)
        for i in range(1, 13):
            x = int(rect.width() * i / 13)
            painter.drawLine(x, 0, x, rect.height())
        painter.setPen(QColor("#60758b"))
        font = QFont("Consolas", 11)
        painter.setFont(font)
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "WAITING FOR VALIDATED OHLCV DATA\n\nNo price candles are being fabricated.")
        painter.end()
