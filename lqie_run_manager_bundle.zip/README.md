# Lionare Desktop 0.1.0 — drop-in package

This package adds `apps/lionare_desktop` to the existing Lionare repository. It does not overwrite the browser prototype, LQIE, ingestion scripts or data lake.

The first development build provides a native PySide6 window with dockable panels, workspace presets, local layout persistence, system status, company research through the existing API, a local Parquet inventory, and news display. Market prices and candles are deliberately marked unavailable until a permitted OHLCV feed is connected.

Read `apps/lionare_desktop/README.md` for the full install and run commands. The simplest Windows setup is:

```powershell
cd C:\lionare
py -3.12 -m venv .venv-desktop
.\.venv-desktop\Scripts\python.exe -m pip install --upgrade pip
.\.venv-desktop\Scripts\python.exe -m pip install -r apps\lionare_desktop\requirements.txt
$env:LIONARE_API_URL = "http://127.0.0.1:8765"
$env:LIONARE_DATA_LAKE = "\\wsl.localhost\Ubuntu\home\ishendra\lionare-data"
.\.venv-desktop\Scripts\python.exe apps\lionare_desktop\main.py
```

Run the existing Lionare service separately in WSL Ubuntu:

```bash
cd /mnt/c/lionare
source venv/bin/activate
python3 apps/lionare_terminal/server.py
```

Do not install PySide6 into the main LQIE `venv`; the desktop uses `.venv-desktop` so the quantitative environment remains isolated.
